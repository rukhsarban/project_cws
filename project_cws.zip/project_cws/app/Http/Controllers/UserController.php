<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller {

	// set index page view
	

	// handle fetch all User 
	public function fetchAll() {
		$Users = User::all();
		$output = '';
		if ($Users->count() > 0) {
			$output .= '<table class="table table-striped table-sm text-center align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>profile</th>
                <th>Name</th>
              
                <th>E-mail</th>
                <th>dob</th>
                <th>Phone</th>
                <th>gender</th>
                <th>Address</th>
                
                <th>Action</th>
              </tr>
            </thead>
            <tbody>';
			foreach ($Users as $User) {
				$output .= '<tr>
                <td>' . $User->id . '</td>
                
                <td><img src="image/'.$User->image.'" width="50" class="img-thumbnail rounded-circle"></td>
                <td>' . $User->firstname . ' ' . $User->lastname . '</td>
                <td>' . $User->email . '</td>
                <td>' . $User->dob . '</td>
                <td>' . $User->phone . '</td>
                <td>' . $User->gender . '</td>
                <td>' . $User->address . '</td>
                
                <td>
                  <a href="#" id="' . $User->id . '" class="text-success mx-1 editIcon" data-bs-toggle="modal" data-bs-target="#editUserModal"><i class="bi-pencil-square h4"></i></a>
                 
                  <a href="#" id="' . $User->id . '" class="text-danger mx-1 deleteIcon"><i class="bi-trash h4"></i></a>
                  <a href="#" id="' . $User->id . '" class="text-info mx-1 viewIcon" data-bs-toggle="modal" data-bs-target="#viewUserModal"><i class="bi-eye-fill h4"></i></a>
                </td>
              </tr>';
			}
			$output .= '</tbody></table>';
			echo $output;
		} else {
			echo '<h1 class="text-center text-secondary my-5">No record present in the database!</h1>';
		}
	}

	
	

	// handle edit an User
	public function edit(Request $request) {
		$id = $request->id;
		$User = User::find($id);
        
		return response()->json($User);
	}
// handle view user 
public function view(Request $request) {
    $id = $request->id;
    $User = User::find($id);
   
    return response()->json($User);
}
	// handle update an User
	public function update(Request $request) {
		$fileName = '';
		$User = User::find($request->User_id);

		$UserData = ['firstname' => $request->fname,
         'lastname' => $request->lname, 
         'email' => $request->email,
          'phone' => $request->phone, 
          'dob' => $request->dob, 
          'gender' => $request->gender,
          'address' => $request->address
        ];

		$User->update($UserData);
		return response()->json([
			'status' => 200,
		]);
	}

	// handle delete an User
	public function delete(Request $request) {
		$id = $request->id;
		$User = User::find($id);
        User::destroy($id);
		
	}
}